# A.R.E.S. — shaxsiy AI yordamchi (PWA + FastAPI)

## 1. Joylash (Render, Railway yoki VPS)
1. Papkani GitHub'ga yuklang. Render'da "New Web Service" -> Docker -> shu repo.
2. Environment'ga `.env.example` dagi o'zgaruvchilarni kiriting. `BASE_URL` = sayt manzili (https).
3. **Doimiy disk (volume)** ulang va `/app/data` ga mounting qiling, aks holda xotira har deploydan so'ng o'chadi.
4. `https://sizning-domen/health` -> `{"status":"ok"}` bo'lsa tayyor.

Lokal sinov: `pip install -r backend/requirements.txt`, `.env` o'zgaruvchilarini export qiling, `uvicorn backend.main:app --reload`.

## 2. Integratsiyalar
- **Gmail:** Google Cloud Console -> Gmail API yoqing -> OAuth client (Web) -> redirect URI: `BASE_URL/oauth/gmail`. Test rejimida o'z emailingizni "Test users"ga qo'shing. Ruxsatlar: gmail.readonly, gmail.send.
- **Telegram:** @BotFather'dan bot oching, tokenni ilovada "Ulanish" bo'limiga kiriting, so'ng botga ko'rsatilgan `/start KOD` ni yozing. Faqat siz (juftlangan chat) botga buyruq bera olasiz. Oddiy bot shaxsiy akkauntdagi suhbatlarni o'qiy olmaydi.
- **Instagram:** Meta Developers -> "Instagram API with Instagram Login". Redirect: `BASE_URL/oauth/instagram`. Faqat Business/Creator akkaunt. Boshqa foydalanuvchilar uchun Meta app review kerak; o'z akkauntingiz uchun app'ni Development rejimida ishlatish mumkin.

## 3. APK (PWABuilder)
1. https://www.pwabuilder.com -> sayt manzilingizni kiriting.
2. Manifest va Service Worker yashil bo'lishi kerak -> "Package for stores" -> Android -> APK/AAB yuklab oling.
3. Telefonga o'rnatish: APK'ni oching, "noma'lum manbalardan o'rnatish"ga ruxsat bering.
4. To'liq ekran (URL satrisiz) ishlashi uchun PWABuilder bergan `assetlinks.json` ni `frontend/.well-known/assetlinks.json` ga qo'ying.

## 4. Cheklovlar (halol ro'yxat)
- "A.R.E.S." deb doimiy tinglash yo'q: ovoz mikrofon tugmasi orqali (brauzer cheklovi).
- Mahalliy (offline) AI yo'q. Offline'da faqat oxirgi ko'rilgan xotira/vazifalar ko'rinadi.
- Boshqa ilovalarni ochish, batareya, boshqa ilovalar bildirishnomalarini o'qish PWA'da mumkin emas.
- Jonli hodisalar: Gmail har 2 daqiqada tekshiriladi (push emas); Telegram webhook orqali darhol.
- Instagram DM/izoh ruxsatlari so'ralgan, lekin hozirgi interfeys faqat profil va post statistikasini ko'rsatadi.
- Bitta foydalanuvchi (egasi) uchun mo'ljallangan. Kodni men sinab ko'rmadim: ulashlarni haqiqiy akkauntlar bilan sinab, xatolarni menga yuboring.
