const V="ares-v1",SHELL=["/","/manifest.json","/icons/icon-192.png"],OFF=["/api/memory","/api/tasks"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)));self.skipWaiting()});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))));self.clients.claim()});
self.addEventListener("fetch",e=>{
  const r=e.request,u=new URL(r.url);if(r.method!=="GET"||u.origin!==location.origin||u.pathname==="/api/events"||u.pathname.startsWith("/oauth"))return;
  if(u.pathname.startsWith("/api/")){
    if(!OFF.includes(u.pathname))return;
    e.respondWith(fetch(r).then(x=>{const c=x.clone();caches.open(V).then(h=>h.put(u.pathname,c));return x}).catch(()=>caches.match(u.pathname)));return}
  e.respondWith(fetch(r).then(x=>{const c=x.clone();caches.open(V).then(h=>h.put(r,c));return x}).catch(()=>caches.match(r)))});
